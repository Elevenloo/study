#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
重新生成 DSE2027_关键日程.ics
用法：python3 build_calendar.py
改了考试日 / 补课表 / 阶段 Gate 后跑一次，再把 .ics 汇入手机日历。

时区处理：香港 UTC+8，事件一律写成 UTC (Z)，避开 VTIMEZONE 相容性问题。
全天事件用 VALUE=DATE。换行统一 CRLF（RFC 5545）。
"""
from datetime import date, time, datetime, timedelta, timezone
from pathlib import Path

OUT = Path(__file__).with_name("DSE2027_关键日程.ics")
HK_OFFSET = 8  # Asia/Hong_Kong = UTC+8

def esc(s: str) -> str:
    return s.replace("\\", "\\\\").replace(",", "\\,").replace(";", "\\;").replace("\n", "\\n")

def fold(line: str, limit: int = 70) -> str:
    """RFC 5545 行折叠：按字符累加字节数，避免切断 UTF-8 多字节中文字。"""
    out, cur, n = [], "", 0
    for ch in line:
        b = len(ch.encode("utf-8"))
        if n + b > limit:
            out.append(cur)
            cur, n = " ", 1  # 续行以空格开头
        cur += ch
        n += b
    out.append(cur)
    return "\r\n".join(out)

def utc(d: date, t: time) -> str:
    """本地 (HK) 日期時間 → UTC 字串"""
    dt = datetime.combine(d, t) - timedelta(hours=HK_OFFSET)
    return dt.strftime("%Y%m%dT%H%M%SZ")

def allday(d: date, end: date = None) -> tuple:
    e = end or (d + timedelta(days=1))
    return f"VALUE=DATE:{d.strftime('%Y%m%d')}", f"VALUE=DATE:{e.strftime('%Y%m%d')}"

EVENTS = []

def add(summary, d, t=None, dur_min=0, end_date=None, desc="", alarm=True, uid=None):
    uid = uid or f"dse2027-{len(EVENTS)+1:03d}@local"
    if t is None:
        start, end = allday(d, end_date)
        start_line, end_line = f"DTSTART;{start}", f"DTEND;{end}"
    else:
        s = utc(d, t)
        e = (datetime.combine(d, t) + timedelta(minutes=dur_min) - timedelta(hours=HK_OFFSET)).strftime("%Y%m%dT%H%M%SZ")
        start_line, end_line = f"DTSTART:{s}", f"DTEND:{e}"
    lines = [
        "BEGIN:VEVENT", f"UID:{uid}",
        f"DTSTAMP:{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}",
        start_line, end_line,
        f"SUMMARY:{esc(summary)}",
        f"DESCRIPTION:{esc(desc)}",
        "CATEGORIES:DSE2027",
    ]
    if alarm and t is not None:
        lines += [
            "BEGIN:VALARM", "TRIGGER:-PT30M", "ACTION:DISPLAY",
            f"DESCRIPTION:{esc(summary)}", "END:VALARM",
        ]
    lines.append("END:VEVENT")
    EVENTS.append("\r\n".join(fold(x) for x in lines))

# ---------- 1. 官方考期（HKEAA 通告 (8) 2025/2026 + 重要日期页） ----------
add("🔴 DSE 英文口试期开始（暂定 3/9–3/18）", date(2027,3,9),
    desc="比笔试早约一个月；2 月起每周小组模拟，3 月前完成 3 次全真模拟。以准考證为准。", uid="dse2027-oral-start")
add("英文口试期结束", date(2027,3,18), desc="当日回归笔试节奏。", uid="dse2027-oral-end")
add("DSE 2027 笔试期开始（作息切换考试模式）", date(2027,4,6), desc="笔试 4/6–5/3 暂定。", uid="dse2027-written-start")

EXAM = [
    (date(2027,4,8),  "📝 中国语文 卷一＋卷二", "目标稳守 3。前夜只看文体结构卡 20′，不重读范文。"),
    (date(2027,4,9),  "📝 英国语文 卷一＋卷二", "中文翌日即考；4/8 晚不复盘中文，只做 P2 模板 20′ + P1 扫读 15′。"),
    (date(2027,4,10), "🔴 英国语文 卷三（聆听及综合）【周六】", "最弱项，且是星期六。平日模考固定周六 09:15 计时，对齐生理时钟。"),
    (date(2027,4,12), "📝 数学 必修部分 卷一＋卷二", "4/11 缓冲日只做 MC 手感 20′。"),
    (date(2027,4,13), "📝 公民与社会发展", "2h 资料回应题，只报达标；答題链：读资料→用概念→作回应。"),
    (date(2027,4,15), "🔴 化学 卷一＋卷二", "卷二须选答两个选修（第二选修待确认）。4/14 空档只做错题红标。"),
    (date(2027,4,21), "📝 物理 卷一＋卷二（E2 原子世界 + E3 能源）", "写完整步骤拿方法分；E3 单位换算最易错。"),
    (date(2027,4,23), "📝 数学延伸部分 M2", "最后一科；4/22 只有 1 天，故 M2 必须 3 月已完成整卷。"),
]
for d, s, desc in EXAM:
    add(s, d, desc=desc, uid="dse2027-exam-"+d.strftime("%m%d"))

add("🎓 DSE 放榜（暂定）＋ JUPAS 改选", date(2027,7,14),
    desc="当日按实际成绩重算 JS3741／JS4408／JS5102 加权分；改选窗口当日开放，是做决定的一天。",
    uid="dse2027-results")

# ---------- 2. 阶段 Gate ----------
GATES = [
    (date(2026,11,28), "P0 Gate：诊断与止血", "基线分数入库；确认化学第二选修、补课表、周四/周日时段制式；tracker 上线。"),
    (date(2027,1,2),   "P1 Gate：基础重建", "英 P3 分节 ≥55%；摩尔计算 ≥70%；七科各产出 1 页知识地图。"),
    (date(2027,2,13),  "P2 Gate：专题攻坚", "化学卷一 MC ≥65%、工业化学 ≥70%；物理 E2/E3 ≥70%；M2 乙部 ≥60%；2 套整卷。"),
    (date(2027,3,20),  "P3 Gate：整卷＋口试", "英 P3 全卷 ≥60%；口试模拟 ≥3 次；理科各 3 套整卷；predicted 上调至 英3／化3-4。"),
    (date(2027,4,7),   "P4 Gate：第一轮复习正式收工 ✅", "错题本只剩红标；公式卡定稿；按考试顺序模拟一轮。4 月只做维持。"),
]
for d, s, desc in GATES:
    add("🚩 " + s, d, time(20,0), 20, desc=desc + " 若未过：顺延该阶段 1 周，从中文/公社时数调，不砍睡眠、不砍英文。",
        uid="dse2027-gate-"+d.strftime("%m%d"))

# ---------- 3. 每周复盘（周日 20:00） ----------
d = date(2026,11,15)  # 周日
while d <= date(2027,4,4):
    add("🔁 周复盘 20′（4 个数字 + 下周预排）", d, time(20,0), 20,
        desc="① 英P3正确率 ② 化学MC正确率 ③ 物理或M2整卷分 ④ 净复习时数；再查 open_items、predicted、下周固定占用。结果写进 state.json。",
        alarm=True, uid="dse2027-review-"+d.strftime("%Y%m%d"))
    d += timedelta(days=7)

# ---------- 4. 周六 09:15 整卷计时（对齐英文 P3 考试钟） ----------
d = date(2026,11,21)
while d <= date(2027,4,3):
    # 考试期前的周六；3/13 落在口试周，改为轻量手感
    light = date(2027,3,9) <= d <= date(2027,3,20)
    add(("🕘 轻量手感（口试周）" if light else "🕘 整卷计时 09:15（对齐 P3 考试钟）"), d, time(9,15), 180,
        desc=("口试周只做 30′ 手感，不占口试日。" if light else "上午计时整卷，下午逐题三分类归因 + 选修单元精读。"),
        alarm=True, uid="dse2027-paper-"+d.strftime("%Y%m%d"))
    d += timedelta(days=7)

# ---------- 5. 关键行政节点 ----------
add("准考證派发（暂定 2027/2 中旬）", date(2027,2,15),
    desc="核对确切考试日期、时间与试场；确认英文口试日期；有变立即更新 state.json.exam_dates。",
    uid="dse2027-admission-ticket")
add("🔴 本周内必办：向化学老师确认卷二第二选修", date(2026,11,18), time(19,15), 15,
    desc="化学卷二须选答两个选修，目前只填工业化学。确认是物料化学还是分析化学，并把结果写入 state.json.open_items #1 与 syllabus_checklist。",
    uid="dse2027-openitem1")

# ---------- 输出 ----------
head = "\r\n".join(fold(x) for x in [
    "BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//DSE2027//Study Plan//ZH",
    "CALSCALE:GREGORIAN", "METHOD:PUBLISH",
    "X-WR-CALNAME:DSE 2027 备考关键日程",
    "X-WR-TIMEZONE:Asia/Hong_Kong",
    "X-WR-CALDESC:依据 HKEAA 2027 考试时间表与 DSE2027 考生档案生成；重跑 build_calendar.py 可更新。",
])
body = "\r\n".join(EVENTS)
OUT.write_text(head + "\r\n" + body + "\r\nEND:VCALENDAR\r\n", encoding="utf-8")
print(f"✅ 已生成 {OUT} ｜ 共 {len(EVENTS)} 个事件")
